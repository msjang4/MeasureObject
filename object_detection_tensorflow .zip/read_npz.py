import numpy as np
loaded =np.load('param.npz')
mtx = loaded['mtx']
dist = loaded['dist']
cam = loaded['cam']
r = loaded['r']
t = loaded['t']

print (cam)
print (mtx)
mtx_inv = np.linalg.inv(mtx)
fx = mtx[0][0]
fy = mtx[1][1]
cx  = mtx[0][2]
cy = mtx[1][2]
print(fx,fy,cx,cy)

x,y =(299.62489128112793, 307.201566696167)
print((x-cx)/fx, (y-cy)/fy)
u,v, _=np.matmul(mtx_inv, [[x],[y],[1]])
print(np.matmul(mtx_inv, [[x],[y],[1]]))
print(cam)
# print(mtx, dist,r,t)
# print(mtx)
# p1 = [[100],[100],[1]]

# pw = [[3],[320],[0]]
# r_inv = np.transpose(r)
# print(np.matmul(mtx_inv, p1))
# print(p1)
# w1 = np.matmul(r_inv, np.matmul(mtx_inv, p1) - t)
# print(cam,w1)
#print(np.matmul(r_inv, [[0],[0],[0]]-t)) # 카메라 좌표에서 월드좌표
# print(r)
# print(np.matmul(r, [[1],[2],[0]]))
# pc = np.matmul(r, [[1],[2],[0]])+t
# print(pc)#월드 좌표에서 카메라좌표로
# print(np.matmul(mtx, pc))
# print(np.matmul(mtx, pc)/pc[2])
# aaa = [[261.37908175 ], [ 76.14891721],[  1.        ]]
# #print(np.matmul(mtx_inv, aaa))
# print(np.matmul(mtx_inv, aaa)*pc[2])

# print(pc - t)

# print((np.matmul(mtx_inv, aaa)*pc[2]-t))
# print([[1],[2],[0]])
# print(np.matmul(r_inv,(np.matmul(mtx_inv, aaa)*pc[2]-t)))
#print((np.matmul(mtx_inv, aaa) - t)*pc[2])
#print(pc-t)
#print(cam)
