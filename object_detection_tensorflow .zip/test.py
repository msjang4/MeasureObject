import os, shutil,glob
def remove_all_in_folder(folder):
    for the_file in os.listdir(folder):
        file_path = os.path.join(folder, the_file)
        try:
            if os.path.isfile(file_path):
                os.unlink(file_path)
            #elif os.path.isdir(file_path): shutil.rmtree(file_path)
        except Exception as e:
            print(e)
def set_d1():
    images = glob.glob("images/image_*.jpg")
    max_d1 =0 
    for image_name in images:
        sub_str = image_name[len("images/image_"):]
        sliced_idx = sub_str.find("_")
        d1 = int(sub_str[:sliced_idx])
        max_d1 = max(d1, max_d1)
    
    return max_d1+1
def xx():
    exec(
'''
global x
x=23
''')


# remove_all_in_folder('images')
# print(set_d1())
xx()
print(x)

