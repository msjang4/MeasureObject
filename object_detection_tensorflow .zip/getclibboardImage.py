from PIL import ImageGrab
import numpy as np
import cv2
frame = ImageGrab.grabclipboard()
frame = np.array(frame)
frame=cv2.cvtColor(frame,cv2.COLOR_BGR2RGB)
cv2.imshow('frame',frame)
print(frame.shape)
while cv2.waitKey(1) < 0:
    pass