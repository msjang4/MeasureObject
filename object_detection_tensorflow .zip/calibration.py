import numpy as np
import glob
import cv2 as cv
import cv2

class Calibrater():
    def __init__(self, fname,w_k=1, h_k=1):
        loaded =np.load(fname)
        self.mtx = loaded['mtx']
        self.mtx_inv = np.linalg.inv(self.mtx)
        self.dist = loaded['dist']
        self.cam = loaded['cam']
        self.r = loaded['r']
        self.r_inv = np.transpose(self.r)
        self.t = loaded['t']
        self.w_k = w_k
        self.h_k = h_k
        #self.
    # img = cv.imread(fname)
    def image_point2world_point(self, image_point):
        # # 영상좌표 -> 정규좌표
        # u, v, _ =np.matmul(mtx_inv, point)
        
        # # 정규좌표 -> 카메라좌표
        # pc = [[u],[v],[1]]

        # 영상좌표 ->  정규좌표 ->카메라 좌표
        p_c = np.matmul(self.mtx_inv,[[image_point[0]], [image_point[1]],[1]])
        p_w = np.matmul(self.r_inv, p_c - self.t)
        
        # cam과 p_w좌표를 잇는 직선 위의 임의의 점은
        # P = cam + k(p_w - cam)으로 표현할 수 있다.
        # k는 임의의 상수
        
        # 직선과 지면의 교차점도 위 식으로 표현가능하며,
        # 즉 P[2] = cam[2] + k (p_w[2] - cam[2])인데
        # 지면좌표는 P[2]가 0이므로 
        # k = -cam[2] /(p_w[2] - cam[2])로 구할 수 있다. 
        k = - self.cam[2] /(p_w[2] - self.cam[2])
        P = self.cam + k *(p_w -self.cam)

        return P

        

    def get_world_size(self, left,right,top,bottom):
        
        
        # h _obj 구하기
        p1 = ((left+right)/2,bottom)
        p2 = ((left+right)/2, top)

        w1 = self.image_point2world_point(p1)
        w2 = self.image_point2world_point(p2)
        d1 = ((w1[0]-self.cam[0])**2 + (w1[1]-self.cam[1])**2) **(1/2)
        d2 = ((w2[0]-self.cam[0])**2 + (w2[1]-self.cam[1])**2) **(1/2)
        # h_cam : d2 = h_obj : d2-d1
        h_obj  = self.cam[2] * (d2-d1)/d2

        # w_ obj 구하기
        pl = (left, bottom)
        pr = (right, bottom) 

        wl = self.image_point2world_point(pl)
        wr =  self.image_point2world_point(pr)
        w_obj = (( wl[0] - wr[0])**2 + (wl[1] - wr[1])**2)**(1/2)

        

        return  self.w_k*w_obj,self.h_k*h_obj


    def undistort(self, img):
        h,  w = img.shape[:2]
        newcameramtx, roi = cv.getOptimalNewCameraMatrix(self.mtx, self.dist, (w,h), 1, (w,h))

        # undistort
        dst = cv.undistort(img, self.mtx, self.dist, None, newcameramtx)
        # crop the image
        #x, y, w, h = roi
        #dst = dst[y:y+h, x:x+w]
        # cv.imwrite('undistored_{}.png'.format(fname), dst)
        # cv.imshow('undistorted', dst)
        # if cv.waitKey(1) > 0:
        #     break
        return dst
if __name__ == '__main__':
    capture = cv2.VideoCapture(0)
    capture.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
    capture.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
    ret, img = capture.read()