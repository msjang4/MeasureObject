# camera.py

import cv2

class VideoCamera(object):
    def __init__(self):
        # Using OpenCV to capture from device 0. If you have trouble capturing
        # from a webcam, comment the line below out and use a video file
        # instead.
        self.video = cv2.VideoCapture(0)
        # If you decide to use video.mp4, you must have this file in the folder
        # as the main.py.
        # self.video = cv2.VideoCapture('video.mp4')

    def __del__(self):
        self.video.release()

    def get_frame(self):
        # Grab a single frame of video
        ret, frame = self.video.read()
        return frame


if __name__ == '__main__':
    cam = VideoCamera()
    while True:
        frame = cam.get_frame()
        h,w,_ = frame.shape
        m=2
        size = (640,480)
        dsize = (w*m,h*m)
        #dsize = size
        cubic = cv2.resize(frame, dsize=dsize, interpolation=cv2.INTER_CUBIC)
        # show the frame
        # cv2.imshow("Frame", cubic)
        # key = cv2.waitKey(1) & 0xFF
        # dsize = size

        for i in range (0,3):
            for j in range(0,3):
                row_range = (int(dsize[1]/3 * i), int(dsize[1]/3 * (i+1)))
                col_range = (int(dsize[0]/3 * j), int(dsize[0]/3 * (j+1)))
                print(row_range, col_range)
                cubic = cv2.resize(cubic[row_range[0]:row_range[1], col_range[0]:col_range[1]], dsize=dsize, interpolation=cv2.INTER_CUBIC)
                # cubic = detector.detect_objects(cubic)
                cv2.imshow("Cubic "+"%d %d" % (i+1,j+1), cubic)

        # if the `q` key was pressed, break from the loop
        # if key == ord("q"):
        #     break
        q= False
        flag = False
        while True:
            key = cv2.waitKey(1) 
            if key == ord("q"):
                q= True
                break
            elif key > 0:
                break
        if q:
            break

    # do a bit of cleanup
    cv2.destroyAllWindows()
    print('finish')
