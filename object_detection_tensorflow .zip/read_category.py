import numpy as np
loaded= np.load('category.npz', allow_pickle=True)
category = loaded['category']
category = np.array(category).reshape(-1)[0]
name_list = [ category[i]['name'] for i in category]
print('\n'.join(name_list) )