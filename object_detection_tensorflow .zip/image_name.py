from PIL import ImageGrab
import cv2
import glob
images = glob.glob('images/*.jpg')
def getfname():
    indexes = []
    for image_name in images:
        sliced = image_name[len('images/image_'):]
        slice_idx =sliced.find('_')
        # print(sliced, slice_idx)
        slice_idx =-len('.jpg') if slice_idx == -1 else slice_idx 
        indexes.append(sliced[:  slice_idx])
    # print(indexes)
    indexes = list(map(int, indexes))
    print(indexes)
    max_idx = max(indexes)
    fname = 'images/image_'+str(max_idx+1)+'.jpg'
    print(fname)

    return fname
getfname()
exit()
frame = ImageGrab.grabclipboard()
frame.save(getfname())